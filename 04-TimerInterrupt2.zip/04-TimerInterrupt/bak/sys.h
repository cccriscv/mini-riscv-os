#ifndef __SYS_H__
#define __SYS_H__

#include "riscv.h"
extern reg_t trap_handler(reg_t epc, reg_t cause);
extern void sys_switch(struct context *ctx_old, struct context *ctx_new);

#endif
