#include "os.h"

void os_loop(void) {
	while (1) {} // os : do nothing, just loop!	
}

int os_main(void)
{
	lib_puts("OS start\n");
	timer_init(); // start timer interrupt ...
	os_loop();
	return 0;
}

