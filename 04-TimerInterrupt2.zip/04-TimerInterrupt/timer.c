#include "timer.h"

extern void os_loop();

// a scratch area per CPU for machine-mode timer interrupts.
reg_t timer_scratch[NCPU][4];

#define interval 10000000 // cycles; about 1 second in qemu.

void timer_init()
{
  // each CPU has a separate source of timer interrupts.
  int id = r_mhartid();

  // ask the CLINT for a timer interrupt.
  *(reg_t*)CLINT_MTIMECMP(id) = *(reg_t*)CLINT_MTIME + interval;

  // prepare information in scratch[] for timervec.
  // scratch[0..2] : space for timervec to save registers.
  // scratch[3] : address of CLINT MTIMECMP register.
  reg_t *scratch = &timer_scratch[id][0];
  scratch[3] = CLINT_MTIMECMP(id);
  w_mscratch((reg_t)scratch);

  // set the machine-mode trap handler.
  w_mtvec((reg_t)sys_timer);

  // enable machine-mode interrupts.
  w_mstatus(r_mstatus() | MSTATUS_MIE);

  // enable machine-mode timer interrupts.
  w_mie(r_mie() | MIE_MTIE);
}

static int timer_count = 0;

reg_t timer_handler(reg_t epc, reg_t cause)
{
  reg_t return_pc = epc;
  reg_t cause_code = cause & 0xfff;

  if ((cause & 0x80000000)&&(cause_code==7 /*timer interrupt*/))
  {
      // disable machine-mode timer interrupts.
      w_mie(~((~r_mie()) | (1 << 7)));
      lib_printf("timer_handler: %d\n", ++timer_count);
      int id = r_mhartid();
      *(reg_t *)CLINT_MTIMECMP(id) = *(reg_t *)CLINT_MTIME + interval;
      return_pc = (reg_t)&os_loop;
      // enable machine-mode timer interrupts.
      w_mie(r_mie() | MIE_MTIE);
  }
  else
  {
    lib_puts("Sync exceptions!\n");
    while (1) {} // error: stop!
  }
  return return_pc;
}
